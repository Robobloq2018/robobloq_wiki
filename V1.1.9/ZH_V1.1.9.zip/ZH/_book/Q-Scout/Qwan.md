**玩一玩**

**a）遥控模式**：手动控制机器人运动方向以及光效。
<div align=center>
![](/img/K1/IMG_0055.PNG)

**b\)自动避障模式**:机器人自动避开前方的障碍物。
<div align=center>
![](/img/K1/IMG_0058.PNG)

**c)巡线模式**:  使用产品中的黑色胶带在地面上粘贴上一个环形的路径。把机器人的巡线传感器放在黑线上，然后点击右上角的开关，机器人启动巡线模式。
<div align=center>
![](/img/K2/xun.gif)

**d\)音乐模式**:do re mi fa so la ti 弹奏音乐。
<div align=center>
![](/img/K1/IMG_0056.PNG)
