### 下载专区

电子说明书

---
<div align=center>
[![](/img/K2/Q2_suo.gif)](http://static.robobloq.cn/wiki/20180720/Q-scout-building-instruction.pdf)

<div align=center>
<b><u>[Q-侦察兵](http://static.robobloq.cn/wiki/20180720/Q-scout-building-instruction.pdf)</u>


软件

---
<div align=center>
[![](/img/K1/img_10.png)](http://www.robobloq.cn/support/download)        　　　　　　　　             [![](/img/K1/img_11.png)](http://www.robobloq.cn/support/download)

原理图

---

<b>[Qmindplus原理图](https://github.com/Robobloq2018/Open-source-hardware/tree/master/Electronic%20module)
