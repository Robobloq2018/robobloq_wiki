## 如何更新Robobloq机器人的固件？

1, 更新最新的官方固件

　　1.1 下载地址：http://www.robobloq.com/support/download

![](/img/software/PC_down_ZH.gif)

　　1.2 选择要下载的相应版本，使用win10 X64位版本来演示以下内容

　　1.3 单击Robobloq图标以打开软件　

![](/img/software/ico.png)

　　1.4 安装驱动程序 

![](/img/software/PC_1.gif)　

　　1.5 驱动程序安装完成后，关闭对话框并开始连接机器人。 使用USB电缆连接机器人，然后选择要连接的端口号后，点击“连接”按钮

![](/img/software/PC_2.gif)　

　　1.6 连接成功后，选择恢复出厂固件的选项，选择适当的机器人并单击“更新”按钮以执行固件更新。

![](/img/software/PC_3.gif)　

