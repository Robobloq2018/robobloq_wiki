# 烧录机器人Scratch程序
1、使用套装内配送的USB线连接机器人

2、选择机器人套件

![](/img/software/K1.jpg)  ![](/img/software/K2.jpg)

3、拖动语句块生成程序

> 示例：机器人以60的速度向前运行2秒后停止

![](/img/software/li_01.png)

4、上传程序到机器人主控板

　　4-1、点击 </> ，打开程序面板

![](/img/software/li_02.png)

　　4-2、点击“上传”按钮，上传程序

![](/img/software/li_03.png)

　　4-3、图示：程序正在上传中，需要15秒左右的时间，请耐心等待

![](/img/software/li_04.png)

　　4-4、图示：程序上传成功

![](/img/software/li_05.png)

　　4-5、拔出USB线，打开机器人看看执行效果吧



