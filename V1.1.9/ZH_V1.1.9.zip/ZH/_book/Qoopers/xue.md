如何快速入门图形化编程？参考下方的教程可以循序渐进的学习用图形化编程机器人。

<div align=center>
<b><u>[点击下载](https://static.robobloq.cn/wiki/07.pdf)</u>

<div align=center>
![](/img/K1/img_1.png)
