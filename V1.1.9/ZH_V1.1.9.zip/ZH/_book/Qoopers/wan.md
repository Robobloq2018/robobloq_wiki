**玩一玩**

**a）遥控模式**：手动控制机器人运动方向以及光效。支持形态：六个都支持。
<div align=center>
![](/img/K1/IMG_0055.PNG)

**b\)自动避障模式**:机器人自动避开前方的障碍物。支持形态：探路先锋，巡逻蝎兵。
<div align=center>
![](/img/K1/IMG_0058.PNG)

**c\)点阵屏模式**:自定义绘制矩阵屏的各种表情。支持形态：合金队长，铁甲骑士，矮人护卫。
<div align=center>
![](/img/K1/IMG_0057.PNG)

**d\)音乐模式**:do re mi fa so la ti 弹奏音乐。
<div align=center>
![](/img/K1/IMG_0056.PNG)
