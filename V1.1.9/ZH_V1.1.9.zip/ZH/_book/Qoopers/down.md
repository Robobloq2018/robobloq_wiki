###下载专区

电子说明书

---
<div align=center>
[![](/img/K1/img_4.jpg)](https://static.robobloq.cn/wiki/02.pdf)
　　　　[![](/img/K1/img_5.jpg)](https://static.robobloq.cn/wiki/03.pdf)
　　　　[![](/img/K1/img_6.jpg)](https://static.robobloq.cn/wiki/05.pdf)

<div align=center>
[![](/img/K1/img_7.jpg)](https://static.robobloq.cn/wiki/04.pdf)
　　　　[![](/img/K1/img_8.jpg)](https://static.robobloq.cn/wiki/06.pdf)
　　　　[![](/img/K1/img_9.jpg)](https://static.robobloq.cn/wiki/01.pdf)



软件

---

<div align=center>
[![](/img/K1/img_10.png)](http://www.robobloq.cn/support/download)        　　　　　　　　             [![](/img/K1/img_11.png)](http://www.robobloq.cn/support/download)

原理图

---

<b>[Qmindplus原理图](https://github.com/Robobloq2018/Open-source-hardware/tree/master/Electronic%20module)
