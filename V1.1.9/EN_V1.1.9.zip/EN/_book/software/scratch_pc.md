## 3、Flash Scratch Programs to Robot

1、Use the USB cable to connect robot to computer.

2、Select model.

![](/img/software/K1-01.gif)  ![](/img/software/K2-01.gif)

3、Drag and drop coding blocks and compose your program.

> e.g. make robot go forward at speed 60 for 2 seconds, then stop.

![](/img/software/1109.png)

4、Upload program to robot.

　　4-1、Click </> and expand the panel.

![](/img/software/1109-1.png)

　　4-2、Click “Upload”.

![](/img/software/1109-2.png)

　　4-3、 A dialogue will show and indicate the uploading progress. This usually takes 15 seconds. Please be patient.

![](/img/software/1109-3.png)

　　4-4、 A dialogue will show and say that the program is successfully uploaded.

![](/img/software/1109-4.png)

　　4-5、Pull out the USB cable, then turn on the robot to execute the program.

