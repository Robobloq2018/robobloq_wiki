## 1、Connect robobloq robot

　　1.1 Download address：http://www.robobloq.com/support/download

![](/img/software/PC_down.gif)

　　1.2 Select the appropriate version to download, use win10 X64 bit version to demonstrate the following

　　1.3 Click on Robobloq to open the software　

![](/img/software/ico.png)

　　1.4 Install the driver 

![](/img/software/PC_1.gif)　

　　1.5 After the driver installation is complete, close the dialog and start connecting to the robot. Connect the robot with a USB cable and select the port number to connect to

![](/img/software/PC_2.gif)　

　　1.6 Successful robot connection

