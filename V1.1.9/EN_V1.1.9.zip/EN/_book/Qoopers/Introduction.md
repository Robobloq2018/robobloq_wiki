<div align=center>
![](/img/K1/K1-1.png)

　　Qoopers is a cool app-enabled edutainment robot. By its modularized electronics, sensors and mechanical parts, it can be easily setup within 30 minutes and transformed to more than 15 different varieties like Dozer, Captain Alloy and Scorpoid.

　　Using your smart devices to program Qoopers to move, light up, make sounds, avoid obstacles, and even perform based on your special program. Kids are immersed in cool robots to learn STEAM knowledge, which empowers kids and students hands-on ability and coding skills to bring their innovative ideas into reality.

<div align=center>
![](/assets/K1-2.png)

<div align=center>
Scan the QR code to download APP
