###Playing mode

**a）Remote control：** Manually control the robot’s movement and light efficiency. Which robot is supported? Six robots are all supported.
<div align=center>
![](/img/K1/IMG_0059.PNG)


**b) Obstacle avoidance:** intelligent detection of obstacles, will automatically stop before hitting obstacles. Which robot is supported?：THE VOYAGER，SCORPOID.
<div align=center>
![](/img/K1/IMG_0062.PNG)

**c) Dot matrix:** Various expressions of custom drawing matrix screen. Which robot is supported?：CAPTAIN ALLOY，LI'L GUARDIAN，THE CAVALIER.
<div align=center>
![](/img/K1/IMG_0060.PNG)

**d) Music mode:** do re mi fa so la ti to play music. Which robot is supported? Six robots are all supported.
<div align=center>
![](/img/K1/IMG_0060.PNG)
