###Download

Building instructions

---

<div align=center>
[![](/img/K1/4.jpg)](https://static.robobloq.cn/wiki/02.pdf)
　　　　[![](/img/K1/5.jpg)](https://static.robobloq.cn/wiki/03.pdf)
　　　　[![](/img/K1/6.jpg)](https://static.robobloq.cn/wiki/05.pdf)

<div align=center>
[![](/img/K1/7.jpg)](https://static.robobloq.cn/wiki/04.pdf)
　　　　[![](/img/K1/8.jpg)](https://static.robobloq.cn/wiki/06.pdf)
　　　　[![](/img/K1/9.jpg)](https://static.robobloq.cn/wiki/01.pdf)

Software

---

<div align=center>
[![](/img/K1/img_10.png)](http://www.robobloq.com/support/download)        　　　　　　　　             [![](/img/K1/img_11.png)](http://www.robobloq.com/support/download)

Schematic

---

<b>[Qmind plus Schematic](https://github.com/Robobloq2018/Open-source-hardware/tree/master/Electronic%20module)
