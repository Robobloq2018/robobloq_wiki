How to quickly start graphical programming? Refer to the tutorials below for step-by-step learning to use graphical programming robots.

<div align=center>
<b><u>[DOWN](https://static.robobloq.cn/wiki/20180720/Qoopers-course_EN.pdf)</u>

<div align=center>
[![](/img/K1/Q2_FM.gif)](https://static.robobloq.cn/wiki/20180720/Qoopers-course_EN.pdf)
