### Precautions：

#### Important information about batteries——

1.Try to use batteries of mainstream brands with high performance. It is not recommended to use Zinc-carbon batteries. 

2.Never use different types of batteries together, or a combination of old and new batteries.
 Always remove the batteries if the product is not to be used for a long time or if the batteries have run down. 

3.Never use damaged batteries, or a corresponding type. Insert the batteries so that the poles are correctly positioned. 
Rechargeable batteries must be recharged using the correct battery charger under the supervision of an adult. 

4.You cannot recharge batteries while they are still in the product, and you must never try to do so. 
Never attempt to recharge non-chargeable batteries. Never short-circuit the battery holder. 
