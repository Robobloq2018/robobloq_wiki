###Playing mode

**a）Remote control：** Manually control the robot’s movement and light efficiency.
<div align=center>
![](/img/K1/IMG_0059.PNG)


**b) Obstacle avoidance:** intelligent detection of obstacles, will automatically stop before hitting obstacles.
<div align=center>
![](/img/K1/IMG_0062.PNG)

**c) Line-tracking mode:** Use a black tape from the product to attach a circular path to the ground. Place the robot's line sensor on the black line, then click the switch in the upper right corner to start the line mode.
<div align=center>
![](/img/K2/xun_en.gif)

**d) Music mode:** do re mi fa so la ti to play music. Which robot is supported? Six robots are all supported.
<div align=center>
![](/img/K1/IMG_0060.PNG)
