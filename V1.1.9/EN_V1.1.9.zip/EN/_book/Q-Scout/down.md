###Download

Building instructions

---

<div align=center>
[![](/img/K2/Q2_suo.gif)](http://static.robobloq.cn/wiki/20180720/Q-scout-building-instruction.pdf)

<div align=center>
<b><u>[Q-scout](http://static.robobloq.cn/wiki/20180720/Q-scout-building-instruction.pdf)</u>

Software

---

<div align=center>
[![](/img/K1/img_10.png)](http://www.robobloq.com/support/download)        　　　　　　　　             [![](/img/K1/img_11.png)](http://www.robobloq.com/support/download)

Schematic

---

<b>[Qmind plus Schematic](https://github.com/Robobloq2018/Open-source-hardware/tree/master/Electronic%20module)
